import PaperDriftGame from '@/components/PaperDriftGame'

export default function Home() {
  return <PaperDriftGame />
}